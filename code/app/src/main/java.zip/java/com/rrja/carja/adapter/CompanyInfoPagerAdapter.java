package com.rrja.carja.adapter;

import android.support.v4.view.PagerAdapter;
import android.view.View;

/**
 * Created by chongge on 15/6/24.
 */
public class CompanyInfoPagerAdapter extends PagerAdapter {

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return false;
    }
}
