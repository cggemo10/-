package com.rrja.carja.fragment;



import android.app.Fragment;
import android.view.View;

/**
 * A simple {@link Fragment} subclass.
 */
public abstract class BaseElementFragment extends Fragment implements View.OnKeyListener{


}
