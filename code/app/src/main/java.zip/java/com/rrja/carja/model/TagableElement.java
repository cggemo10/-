package com.rrja.carja.model;

public interface TagableElement {
    public int getTag();
}