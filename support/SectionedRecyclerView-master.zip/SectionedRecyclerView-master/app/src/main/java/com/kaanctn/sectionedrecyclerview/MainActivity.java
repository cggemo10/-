package com.kaanctn.sectionedrecyclerview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        ArrayList<String> rows1 = new ArrayList<>();
        rows1.add("Row 1");
        rows1.add("Row 2");
        rows1.add("Row 3");

        ArrayList<String> rows2 = new ArrayList<>();
        rows2.add("Row 4");
        rows2.add("Row 5");
        rows2.add("Row 6");
        rows2.add("Row 7");
        rows2.add("Row 8");

        ArrayList<String> rows4 = new ArrayList<>();
        rows4.add("Row 9");

        ArrayList<String> rows5 = new ArrayList<>();
        rows5.add("Row 10");
        rows5.add("Row 11");
        rows5.add("Row 12");
        rows5.add("Row 13");


        ArrayList<Section> sections = new ArrayList<>();
        sections.add(new Section("Header 1", rows1));
        sections.add(new Section("Header 2", rows2));
        sections.add(new Section("Header 3", rows4));
        sections.add(new Section("Header 4", rows5));

        MyRecyclerViewAdapter mAdapter = new MyRecyclerViewAdapter(sections);
        mRecyclerView.setAdapter(mAdapter);
    }
}

