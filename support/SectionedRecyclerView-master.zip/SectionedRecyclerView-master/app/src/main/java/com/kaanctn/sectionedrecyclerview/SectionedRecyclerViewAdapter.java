package com.kaanctn.sectionedrecyclerview;

import android.support.v7.widget.RecyclerView;
import android.util.Pair;
import android.view.ViewGroup;

/**
 * Created by kaancetin on 27/06/15.
 */
public abstract class SectionedRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    static class ViewType {
        public static final int HEADER = 0;
        public static final int ROW = 1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == ViewType.HEADER) {
            return onCreateHeaderViewHolder(parent, viewType);
        } else if (viewType == ViewType.ROW) {
            return onCreateRowViewHolder(parent, viewType);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Pair<Integer, Integer> indexPath = calculateIndexPath(position);
        if (isHeaderViewHolder(position)) {
            onBindHeaderViewHolder(holder, indexPath.first);
        } else {
            onBindRowViewHolder(holder, indexPath.first, indexPath.second);
        }
    }

    @Override
    public int getItemCount() {
        int count = 0;
        for (int i = 0; i < getNumberOfSections(); i++) {
            count += getNumberOfRowsInSection(i);
        }
        return count + getNumberOfSections();
    }

    @Override
    public int getItemViewType(int position) {
        if (isHeaderViewHolder(position)) {
            return ViewType.HEADER;
        } else {
            return ViewType.ROW;
        }
    }

    private boolean isHeaderViewHolder(int position) {
        for (int section = 0, count = 0; section < getNumberOfSections(); section++, count++) {
            if (count == position) {
                return true;
            }
            count += getNumberOfRowsInSection(section);
        }
        return false;
    }

    private Pair<Integer, Integer> calculateIndexPath(int position) {
        int p1 = -1;
        int p2 = -1;
        for (int section = 0, count = 0; section < getNumberOfSections(); section++) {
            if (count == position) {
                p1 = section;
                break;
            }
            count += (getNumberOfRowsInSection(section) + 1); // +1 = section header.
            if (count > position) {
                p1 = section;
                p2 = position - (count - getNumberOfRowsInSection(section));
                break;
            }
        }
        return new Pair(p1, p2);
    }

    public abstract RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent, int viewType);

    public abstract void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int section);

    public abstract RecyclerView.ViewHolder onCreateRowViewHolder(ViewGroup parent, int viewType);

    public abstract void onBindRowViewHolder(RecyclerView.ViewHolder holder, int section, int row);

    public abstract int getNumberOfSections();

    public abstract int getNumberOfRowsInSection(int section);
}
