package com.kaanctn.sectionedrecyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by kaancetin on 27/06/15.
 */
public class MyRecyclerViewAdapter extends SectionedRecyclerViewAdapter {

    private ArrayList<Section> mDataSet;

    public MyRecyclerViewAdapter(ArrayList<Section> mDataSet) {
        this.mDataSet = mDataSet;
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_header, parent, false);
        return new HeaderViewHolder(v);
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int section) {
        ((HeaderViewHolder) holder).mTextView.setText(mDataSet.get(section).getHeader());
    }

    @Override
    public RecyclerView.ViewHolder onCreateRowViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_card_view, parent, false);
        return new RowViewHolder(v);
    }

    @Override
    public void onBindRowViewHolder(RecyclerView.ViewHolder holder, int section, int row) {
        ((RowViewHolder) holder).mTextView.setText(mDataSet.get(section).getRows().get(row));
    }

    @Override
    public int getNumberOfSections() {
        return mDataSet.size();
    }

    @Override
    public int getNumberOfRowsInSection(int section) {
        return mDataSet.get(section).getRows().size();
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextView;

        public HeaderViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            mTextView = (TextView) itemLayoutView.findViewById(R.id.header_text);
        }
    }

    public class RowViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextView;

        public RowViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            mTextView = (TextView) itemLayoutView.findViewById(R.id.info_text);
        }
    }
}
