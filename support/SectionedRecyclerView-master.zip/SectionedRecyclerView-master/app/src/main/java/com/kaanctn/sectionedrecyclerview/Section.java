package com.kaanctn.sectionedrecyclerview;

import java.util.ArrayList;

/**
 * Created by kaancetin on 27/06/15.
 */
public class Section {

    private String header;
    private ArrayList<String> rows;

    public Section(String header, ArrayList<String> rows) {
        this.header = header;
        this.rows = rows;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public ArrayList<String> getRows() {
        return rows;
    }

    public void setRows(ArrayList<String> rows) {
        this.rows = rows;
    }
}
