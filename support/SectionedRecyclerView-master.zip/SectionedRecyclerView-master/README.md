
A Simple Sectioned RecyclerView,

Handling the rows / sections logic similar to iOS's UITableView, using SectionedRecyclerViewAdapter.

<img src="https://github.com/kaanctn/SectionedRecyclerView/blob/master/screenshot.png" height="400" />

