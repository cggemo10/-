package com.dovi.stickyparallaxrecyclerview.src.holder;

import android.view.View;

public abstract class ViewHolderParallax extends ViewHolderNormal {

    public ViewHolderParallax(View itemView) {
        super(itemView);
    }

}