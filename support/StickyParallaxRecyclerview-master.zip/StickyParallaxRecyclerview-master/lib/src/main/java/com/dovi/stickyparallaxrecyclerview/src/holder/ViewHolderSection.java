package com.dovi.stickyparallaxrecyclerview.src.holder;

import android.view.View;

/**
 * Created by edouard on 19/12/14.
 */
public abstract class ViewHolderSection extends ViewHolderNormal {

    public ViewHolderSection(View itemView) {
        super(itemView);
    }


}
