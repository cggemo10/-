ImageFilterForAndroid
=====================