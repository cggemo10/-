SharpZipLib
===========

\#ziplib is a Zip, GZip, Tar and BZip2 library written entirely in C# for the .NET platform.

Please see the [\#ziplib homepage](http://icsharpcode.github.io/SharpZipLib/) for precompiled downloads, 
license information, link to the forum (support), release history, samples and more.
